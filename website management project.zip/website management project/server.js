const express = require('express')//function
const app = express()//module
require('dotenv').config()
app.use(express.urlencoded({ extended: false }))
const userRouter = require('./routers/userrouter')
const adminRouter = require('./routers/adminrouter')
const mongoose = require('mongoose')//module
const session = require('express-session')
mongoose.connect(`${process.env.DB_URL}/${process.env.DB_NAME}`)






app.use(session({
    secret: process.env.SECRET_KEY,
    resave: false,
    saveUninitialized: false,
    cookie:{maxAge:1000*60*60*24*365}
}))

app.use(userRouter)//localhost:5000/
app.use('/admin', adminRouter)//localhost:5000/admin/ (use prefix)
app.use(express.static('public'))
app.set('view engine', 'ejs')
app.listen(process.env.PORT, () => { console.log('website development') })