const mongoose = require('mongoose')

const addSchema = mongoose.Schema({
    address: String,
    tel: Number,
    mobile: Number,
    email: String,
    insta: String,
    in: String,
    twit: String,
    about: String
})

module.exports = mongoose.model('address', addSchema)


