const mongoose = require('mongoose')

const testiSchema = mongoose.Schema({
    name: String,
    feedback: String,
    image: String,
    status: { type: String, default: 'Unpublished' },
    postedDate: Date
})


module.exports = mongoose.model('testi', testiSchema)