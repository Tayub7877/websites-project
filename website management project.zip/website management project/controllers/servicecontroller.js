const Service = require('../models/service')

exports.servicepage = async (req, res) => {
    try {
        const loginname = req.session.loginname
        const record = await Service.find().sort({ postedDate: -1 })
        const tservice = await Service.count()
        const tpublished = await Service.count({ status: 'Published' })
        const tunpublished = await Service.count({ status: 'Unpublished' })
        res.render('admin/service.ejs', { loginname, record, tpublished, tunpublished, tservice })
    } catch (error) {
        console.log(error.message)
    }
}

exports.serviceform = (req, res) => {
    try {
        const loginname = req.session.loginname
        res.render('admin/serviceform.ejs', { loginname })
    } catch (error) {
        console.log(error.message)
    }
}

exports.serviceadd = (req, res) => {
    try {
        let currentdate = new Date()
        const filename = req.file.filename
        const { title, desc, moredetails, } = req.body
        const record = new Service({ title: title, desc: desc, moredetails: moredetails, img: filename, postedDate: currentdate })
        record.save()
    } catch (error) {
        console.log(error.message)
    }
}

exports.servicedelete = async (req, res) => {
    try {
        const id = req.params.id
        await Service.findByIdAndDelete(id)
        res.redirect('/admin/service')
    } catch (error) {
        console.log(error.message)
    }
}

exports.servicestatusupdate = async (req, res) => {
    const id = req.params.id
    const record = await Service.findById(id)
    let newstatus = null
    if (record.status == 'Unpublished') {
        newstatus = 'Published'
    } else {
        newstatus = 'Unpublished'
    }
    await Service.findByIdAndUpdate(id, { status: newstatus })
    res.redirect('/admin/service')
}

exports.servicesearch = async (req, res) => {
    const { search } = req.body
    const loginname = req.session.loginname
    const record = await Service.find({ status: search })
    const tservice = await Service.count()
    const tpublished = await Service.count({ status: 'Published' })
    const tunpublished = await Service.count({ status: 'Unpublished' })
    res.render('admin/service.ejs', { loginname, record, tpublished, tunpublished, tservice })
}







