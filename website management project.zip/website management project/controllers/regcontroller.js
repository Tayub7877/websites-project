const reg = require('../models/reg')

exports.loginpage = (req, res) => {
    try {
        res.render('admin/login.ejs', { message: '' })
    } catch (error) {
        console.log(error.message)
    }
}

exports.logincheck = async (req, res) => {
    try {
        const { username, password } = req.body
        const record = await reg.findOne({ username: username })
        if (record !== null) {
            if (record.password == password) {
                req.session.isAuth = true
                req.session.loginname = username
                req.session.userid = record.id
                res.redirect('/admin/dashboard')
            } else {
                res.render('admin/login.ejs', { message: 'wrong credentials' })
            }
        } else {
            res.render('admin/login.ejs', { message: 'wrong credentials' })
        }
    } catch (error) {
        console(error.message)
    }
}

exports.dashboard = (req, res) => {
    try {
        const loginname = req.session.loginname
        res.render('admin/dashboard.ejs', { loginname, message: '' })
    } catch (error) {
        console.log(error.message)
    }
}
exports.changepass = async (req, res) => {
    const loginname = req.session.loginname
    const { npass } = req.body
    const id = req.session.userid
    await reg.findByIdAndUpdate(id, { password: npass })
    req.session.destroy()
    res.render('admin/passwordchangemsg.ejs')
    res.render('admin/dashboard.ejs', { message: 'Password has been changed Successfully', loginname })
}

exports.logout = (req, res) => {
    try {
        req.session.destroy()
        res.redirect('/admin/')
    } catch (error) {
        console.log(error.message)
    }
}