const Banner = require('../models/banner')

exports.bannerpage = async (req, res) => {
    try {
        const loginname = req.session.loginname
        const record = await Banner.findOne()
        res.render('admin/banner.ejs', { loginname, record })
    } catch (error) {
        console.log(error.message)
    }
}

exports.bannerupdateform = async (req, res) => {
    try {
        const id = req.params.id
        const record = await Banner.findById(id)
        const loginname = req.session.loginname
        res.render('admin/bannerform.ejs', { loginname, record })
    } catch (error) {
        console.log(error.message)
    }
}

exports.bannerupdate = async (req, res) => {
    try {
        const id = req.params.id
        const { title, desc, moredetail } = req.body
        if (req.file) {
            const filename = req.file.filename
            await Banner.findByIdAndUpdate(id, { title: title, desc: desc, moredetails: moredetail, img: filename })
        } else {
            await Banner.findByIdAndUpdate(id, { title: title, desc: desc, moredetails: moredetail })
        }
        res.redirect('/admin/banner')
    } catch (error) {
        console.log(error.message)
    }
}

exports.bannerdetails = async (req, res) => {
    try {
        const record = await Banner.findOne()
        res.render('banner.ejs', { record })
    } catch (error) {
        console.log(error.message)
    }
}