const Testi = require('../models/testi')

exports.testipage = (req, res) => {
    res.render('testipage.ejs')
}

exports.testidata = (req, res) => {
    let currentdate = new Date()
    const { name, feedback } = req.body
    if (req.file) {
        const filename = req.file.filename
        var record = new Testi({ name: name, feedback: feedback, image: filename, postedDate: currentdate })
        record.save()
    } else {
        const filename = 'default.jpg'
        var record = new Testi({ name: name, feedback: feedback, image: filename, postedDate: currentdate })
    } record.save()
}

exports.testino = async (req, res) => {
    const loginname = req.session.loginname
    const testicount = await Testi.count()
    const publishedcount = await Testi.count({ status: 'Published' })
    const unpublishedcount = await Testi.count({ status: 'Unpublished' })
    const record = await Testi.find()
    res.render('admin/testino.ejs', { loginname, record, testicount, publishedcount, unpublishedcount })
}

exports.testidelete = async (req, res) => {
    const id = req.params.id
    await Testi.findByIdAndDelete(id)
    res.redirect('/admin/testino')
}

exports.statusupdate = async (req, res) => {
    const id = req.params.id
    const record = await Testi.findById(id)
    //console.log(record)
    let newstatus = null
    if (record.status == 'Unpublished') {
        newstatus = 'Published'
    } else {
        newstatus = 'Unpublished'
    }
    await Testi.findByIdAndUpdate(id, { status: newstatus })
    res.redirect('/admin/testino')
}

exports.testisearch = async (req, res) => {
    const { search } = req.body
    const loginname = req.session.loginname
    const testicount = await Testi.count()
    const publishedcount = await Testi.count({ status: 'Published' })
    const unpublishedcount = await Testi.count({ status: 'Unpublished' })
    const record = await Testi.find({ status: search })
    //console.log(searchrecord)
    res.render('admin/testino.ejs', { loginname, record, testicount, publishedcount, unpublishedcount })
}


