const Query = require('../models/query')
const nodemailer = require('nodemailer')

exports.queryinsert = (req, res) => {
    const { email, query } = req.body
    const record = new Query({ email: email, query: query })
    record.save()
    //console.log(record)
}

exports.querypage = async (req, res) => {
    const loginname = req.session.loginname
    const record = await Query.find().sort({ status: -1 })
    res.render('admin/query.ejs', { loginname, record })
}

exports.queryform = async (req, res) => {
    const loginname = req.session.loginname
    const id = req.params.id
    const record = await Query.findById(id)
    res.render('admin/queryform.ejs', { loginname, record })
}

exports.emailsend = async (req, res) => {
    const id = req.params.id
    const { emailto, emailfrom, subject, body } = req.body

    //let testAccount = await nodemailer.createTestAccount();
    const transporter = nodemailer.createTransport({
        host: "smtp.gmail.com",
        port: 587,
        secure: false,
        auth: {
            user: 'khantayub781@gmail.com',
            pass: 'owry rfgz pahb tuog',
        },
    });
    const info = await transporter.sendMail({
        from: emailfrom, // sender address
        to: emailto, // list of receivers
        subject: subject, // Subject line
        text: body, // plain text body
        //html: "<b>Hello world?</b>", // html body
        //attachments:[{
        //path:path
        //}]
    })
    console.log("emailsend")
    await Query.findByIdAndUpdate(id, { status: 'Replied' })
    res.redirect('/admin/query')
}