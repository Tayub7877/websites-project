const Add = require('../models/address')

exports.addpage = async (req, res) => {
    const loginname = req.session.loginname
    const record = await Add.findOne()
    res.render('admin/add.ejs', { loginname, record })
}
exports.addform = async (req, res) => {
    const id = req.params.id
    const loginname = req.session.loginname
    const record = await Add.findById(id)
    res.render('admin/addupdateform.ejs', { loginname, record })
}
exports.addupdate = async (req, res) => {
    const { address, tel, mobile, email, insta, lin, twit, about } = req.body
    const id = req.params.id
    const record = await Add.findByIdAndUpdate(id, { address: address, tel: tel, mobile: mobile, email: email, insta: insta, in: lin, twit: twit, about: about })
    res.redirect('/admin/add')
}