const router = require('express').Router()
const regc = require('../controllers/regcontroller')
const bannerc = require('../controllers/bannercontroller')
const servicec = require('../controllers/servicecontroller')
const testic = require('../controllers/testicontroller')
const queryc = require('../controllers/querycontroller')
const addc = require('../controllers/addresscontorller')


const upload = require('../helpers/multer')
const handlelogin = require('../helpers/handlelogin')


router.get('/', regc.loginpage)
router.post('/', regc.logincheck)
router.get('/dashboard', handlelogin, regc.dashboard)
router.post('/dashboard', regc.changepass)
router.get('/logout', regc.logout)
router.get('/banner', handlelogin, bannerc.bannerpage)
router.get('/Bannerupdate/:id', handlelogin, bannerc.bannerupdateform)
router.post('/Bannerupdate/:id', handlelogin, upload.single('img'), bannerc.bannerupdate)
router.get('/Service', handlelogin, servicec.servicepage)
router.get('/serviceadd/', handlelogin, servicec.serviceform)
router.post('/serviceadd', upload.single('img'), servicec.serviceadd)
router.get('/servicedelete/:id', handlelogin, servicec.servicedelete)
router.get('/servicestatusupdate/:id', servicec.servicestatusupdate)
router.post('/service', servicec.servicesearch)
router.get('/testino', handlelogin, testic.testino)
router.get('/testidelete/:id', handlelogin, testic.testidelete)
router.get('/testistatusupdate/:id', handlelogin, testic.statusupdate)
router.post('/testino', testic.testisearch)
router.get('/query', handlelogin, queryc.querypage)
router.get('/queryform/:id', handlelogin, queryc.queryform)
router.post('/queryform/:id', upload.single('Attachement'), queryc.emailsend)
router.get('/add', handlelogin, addc.addpage)
router.get('/addupdate/:id', handlelogin, addc.addform)
router.post('/addupdate/:id', addc.addupdate)




module.exports = router