const router = require('express').Router()
const regc = require('../controllers/regcontroller')
const bannerc = require('../controllers/bannercontroller')
const servicec = require('../controllers/servicecontroller')
const testic = require('../controllers/testicontroller')
const queryc = require('../controllers/querycontroller')
const addc = require('../controllers/addresscontorller')


const banner = require('../models/banner')
const Service = require('../models/service')
const multer = require('multer')
const Testi = require('../models/testi')
const Add = require('../models/address')

let storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './public/upload')
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + file.originalname)
    }
})
let upload = multer({
    storage: storage,
    limits: { fileSize: 1024 * 1024 * 4 }
})



router.get('/', async (req, res) => {
    const bannerrecord = await banner.findOne()
    const serviceRrcord = await Service.find({ status: 'Published' }).sort({ postedDate: -1 })
    const testirecord = await Testi.find({ status: 'Published' })
    const addrecord = await Add.findOne()
    res.render('newbatchproject.ejs', { bannerrecord, serviceRrcord, testirecord, addrecord })
})
router.get('/testipage', testic.testipage)
router.post('/testipage', upload.single('image'), testic.testidata)

router.get('/banner', bannerc.bannerdetails)
router.post('/', queryc.queryinsert)








module.exports = router